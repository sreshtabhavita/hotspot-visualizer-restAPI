package com.example.Gethotspots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GethotspotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GethotspotsApplication.class, args);
	}

}
