package com.example.Gethotspots.model;

import java.io.Serializable;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "STATES_HOTSPOT")

public class statesEnt implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public statesEnt(String statename, String districtname) {
		super();
		this.statename = statename;
		this.districtname = districtname;
	}

	public statesEnt() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@Column(name="STATE_NAME")
	private String statename;
	

	// ... other fields, constructors, and methods

	public String getStatename() {
		return statename;
	}

	@Column(name="DISTRICT_NAME")
	public String districtname;

	
	public void setStatename(String statename) {
		this.statename = statename;
	}

	public String getDistrictname() {
		return districtname;
	}


	public void setDistrictname(String districtname) {
		this.districtname = districtname;
	}
}
