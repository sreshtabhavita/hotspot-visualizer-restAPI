package com.example.Gethotspots.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Gethotspots.model.statesEnt;


@Repository
public interface statesRepository extends JpaRepository<statesEnt, String> {

	List<statesEnt> findAll();
	List<statesEnt> findByStatename(String statename);

	/*@Query("SELECT DISTINCT s.district_name FROM states s WHERE s.state_name = :state_name")
	List<String> findAllDistinctDistrictsByState(String state_name);


	@Query("SELECT DISTINCT s.state_name FROM states s")
	List<stateInterface> findAllDistinctStates();*/

	// You can add additional custom query methods as needed

}