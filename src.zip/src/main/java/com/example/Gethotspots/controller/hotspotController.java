package com.example.Gethotspots.controller;

import java.util.ArrayList;

import java.util.List;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Gethotspots.model.statesEnt;
import com.example.Gethotspots.repository.statesRepository;

import org.springframework.http.ResponseEntity;


@RestController
@CrossOrigin(origins = "*") // Allow requests from any domain
public class hotspotController {

	@GetMapping("/home")
	public String home() {
		return "this is home page ";
	}
	
	@Autowired
	private statesRepository statesRepository;

	@GetMapping("/states")
    public List<statesEnt> getAllStates() {
		return statesRepository.findAll();
    }

    @GetMapping("/states/{id}")
    public List<statesEnt> getDist(@PathVariable(value = "id") String statename) {
        System.out.println("state received: " + statename);
        List<statesEnt> list = statesRepository.findByStatename(statename);
        return list;
    }
    
    
  /*  @GetMapping("/geturl/{district}")
    public List<String> getUrl(@PathVariable String district,
                               @RequestParam String startDate,
                               @RequestParam String endDate) {
        List<String> urls = new ArrayList<>();

        String url1 = "C:\\Users\\UOPS\\Documents\\NetBeansProjects\\HotspotVisualizer\\images\\"+district+".png";
        urls.add(url1);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Security-Policy", "default-src 'self' http://localhost:8080;");
        return (urls);
    }
    
    @GetMapping("/geturl/{district}")
    public ResponseEntity<List<String>> getUrl(@PathVariable String district,
                                               @RequestParam String startDate,
                                               @RequestParam String endDate) {
        List<String> urls = new ArrayList<>();
        String url1 = "C:\\Users\\UOPS\\Documents\\NetBeansProjects\\HotspotVisualizer\\images\\" + district + ".png";
        urls.add(url1);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Security-Policy", "default-src 'self' http://localhost:2222;");
        return ResponseEntity.ok().headers(headers).body(urls);
    }*/
    
    @GetMapping("/geturl/{district}")
    public ResponseEntity<List<String>> getUrl(@PathVariable String district,
                                               @RequestParam String startDate,
                                               @RequestParam String endDate) {
        List<String> base64Images = new ArrayList<>();
        String imagePath = "C:\\Users\\UOPS\\Documents\\NetBeansProjects\\HotspotVisualizer\\images\\" + district + ".png";
        try {
            Path path = Paths.get(imagePath);
            byte[] imageBytes = Files.readAllBytes(path);
            String base64Image = Base64.getEncoder().encodeToString(imageBytes);
            base64Images.add(base64Image);
        } catch (IOException e) {
            // Handle any exceptions
        }

        return ResponseEntity.ok().body(base64Images);
    }


}

